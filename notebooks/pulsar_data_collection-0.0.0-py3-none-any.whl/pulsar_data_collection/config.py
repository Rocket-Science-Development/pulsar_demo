import pulsar_data_collection.database_connectors.influxdb as influxdb

factories = {"influxdb": influxdb.Influxdb()}
